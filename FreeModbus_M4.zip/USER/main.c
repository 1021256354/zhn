/**
  *****************************************************************************
  *                                   ������
  *
  *                       (C) Copyright 2000-2020, ***
  *                             All Rights Reserved
  *****************************************************************************
  *
  * @File    : main.c
  * @By      : �¹�
  * @Version : V1.0
  * @Date    : 2016 / 03 / 07
  *
  *****************************************************************************
  *
  *                                   Update
  *
  * @Version : V1.*
  * @By      : ***
  * @Date    : 20** / ** / **
  * @Brief   : ***
  *
  *****************************************************************************
**/


#include "sys.h"
#include "delay.h"
#include "usart.h"

#include "usmart.h"  //usmart

#include "led.h"
#include "tftlcd.h"

#include "mb.h"  //FreeModbus
#include "mbport.h"
#include "port.h"

/**
  *****************************************************************************
  * @Name   : ������
  *
  * @Brief  : none
  *
  * @Input  : none
  *
  * @Output : none
  *
  * @Return : none
  *****************************************************************************
**/
int main( void )
{
	u8 i = 0;
	
	//
	//��ʼ��Ӳ��
	//
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	delay_init();
	uart_init(38400);
	LED_Init();
	
	usmart_dev.init(72);
	
	LCDTFT_Init();

    eMBInit(MB_RTU, 0x0A, 1, 38400, MB_PAR_NONE);  //��ʼ��FreeModbus

    eMBEnable();  //����FreeModbus
	
	LCD_ShowString(30, 50, 480, 24, 24, "FreeModbus Test.");
	
	while (1)
    {
        (void)eMBPoll();  //��ѯ����֡
		
        usRegInputBuf[0]++;  //���Զ�ȡ����Ĵ�����
		
		if (usRegInputBuf[0] > 250)  //��ֹ����
		{
			usRegInputBuf[0] = 0;
		}
		
		delay_ms(10);
		i++;
		if (i >= 50)
		{
			i = 0;
			LED0 = !LED0;
		}
    }
}

#ifdef  USE_FULL_ASSERT
/** 
  * @brief  Reports the name of the source file and the source line number 
  *         where the assert_param error has occurred. 
  * @param  file: pointer to the source file name 
  * @param  line: assert_param error line source number 
  * @retval None 
  */  
void assert_failed(uint8_t* file, uint32_t line)  
{  
  /* User can add his own implementation to report the file name and line number, 
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */  
   
  /* Infinite loop */  
  while (1)  
  {  
  }  
}
#else
void __aeabi_assert(const char * x1, const char * x2, int x3)
{
}
#endif
